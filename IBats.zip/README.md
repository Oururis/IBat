# IBat
这个资源包的功能很简单，仅仅只是将贴图和声音移除了(仔细看还是能发现一对眼睛，至于为什么我也不知道，我已经将贴图完全修改为透明的了)，实际上蝙蝠还是存在的，如果想要彻底将蝙蝠从你的存档里驱逐，我还有一个很简单的数据包，稍后我会上传，你应该可以在我的主页看到

另外这个资源包理论上来说是全版本通用的，如果有不起作用的版本，你可以下载该版本的任意一个资源包，然后解压它，并且把我的这个资源包也解压出来，然后你就可以照猫画虎的修改它了，可以将这个资源包里的内容与另一个资源包对比，然后将多余的部分删除，将需要的部分复制过去替换，之后再以同样的格式封装它，也就是压缩，这样就完成了。

如果你不会或者不想自己修改，可以到我的github上提交，有时间我会制作,大概吧

the function of this resourcepack is simple,just remove the bat's texture and sound

this means the bat just can't be felt,can't see or hear

well,if look closely you can still see bat's eyes

if you want to remove the bat,I also have a very simple datapack,I will upload later,you should be able to see on my homepage

this resourcepack is theoretically common to all versions,if you encounter a version cannot be used, you can try to adapt it yourself,its simple, or submit it to github,I will adapt it(maybe XD